# AI-Pathfinder
Uninformed search algorithms visualization in a dynamic grid.

# GOOD PERFORMANCE TIME APP — AI Pathfinder
## Overview

This project implements six uninformed search algorithms in a dynamic grid environment with real-time visualization.

Algorithms implemented:

1. Breadth-First Search (BFS)
2. Depth-First Search (DFS)
3. Uniform Cost Search (UCS)
4. Depth-Limited Search (DLS)
5. Iterative Deepening DFS (IDDFS)
6. Bidirectional Search

The system supports dynamic obstacles that may appear during execution, forcing the agent to adapt.

## Features

1. Step-by-step animation
2. Frontier visualization
3. Explored nodes tracking
4. Final path highlighting
5. Dynamic obstacle spawning
6. Re-planning behavior
7. Keyboard controls

## Installation

```bash
pip install pygame